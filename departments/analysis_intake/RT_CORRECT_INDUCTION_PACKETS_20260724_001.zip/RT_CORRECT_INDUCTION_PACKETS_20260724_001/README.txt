RT Correct Induction Packets

This package contains two independent proposal inductions.

Induction here means literal preservation and governed queue registration at first contact.
No review, HOLD, promotion, normalization, interpretation, or source modification is authorized.

The payloads directory contains the complete original proposal JSON files byte-for-byte.
Each INDUCT_*.json file is an intake envelope instructing the program to preserve and register that exact payload.
The earlier RT_INDUCTION_INTAKE_PRESERVATION_FIX_20260724_001.json is governance-only and is not a proposal.
